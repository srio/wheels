=======
Credits
=======

Maintainer
----------

* NSLS-II, Brookhaven National Lab <mrakitin@bnl.gov>

Contributors
------------

None yet. Why not be the first? See: CONTRIBUTING.rst
