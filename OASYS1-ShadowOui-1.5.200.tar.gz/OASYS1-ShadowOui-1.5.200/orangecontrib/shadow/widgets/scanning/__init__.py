NAME = "Shadow Scanning Loops"

DESCRIPTION = "Widgets for Shadow Advanced Tools."

BACKGROUND = "#A9D0F5"#"#0099ff"

ICON = "icons/scanning.png"

PRIORITY = 107.1
