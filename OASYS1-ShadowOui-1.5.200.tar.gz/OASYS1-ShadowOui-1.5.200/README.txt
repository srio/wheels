ShadowOui (Shadow3 Oasys User Interface) is the OASYS (https://www.aps.anl.gov/Science/Scientific-Software/OASYS) add-on for ray tracing simulations.

It uses shadow3 [1] as a ray tracing code, complemented with new tools, among them the HYBRID model for combining ray tracing with wave optics calculations [2] and the DABAM database of experimental metrology measurements or real mirrors [3]
1 https://github.com/oasys-kit/shadow3 http://dx.doi.org/10.1107/S0909049511026306
2 http://dx.doi.org/10.1107/S160057751400650X http://dx.doi.org/10.1117/12.2061950 https://doi.org/10.1117/12.2061984
3 http://dx.doi.org/10.1107/S1600577516005014
