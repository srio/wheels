__author__ = 'labx'

"""
=========
Associate
=========

Widgets for association rules.

"""

# Category description for the widget registry

NAME = "Utility"

DESCRIPTION = "Widgets for Shadow - Utility."

#BACKGROUND = "#FFFFFF"
BACKGROUND = "#A9D0F5"

ICON = "icons/wofry.png"

PRIORITY = 109
