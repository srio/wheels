
NAME = "Special Elements"

DESCRIPTION = "Widgets for Shadow Special Optical Elements."

#BACKGROUND = "#DEDEDE"
BACKGROUND = "#A9D0F5"

ICON = "icons/special_elements.png"

PRIORITY = 104
