"""
=========
Associate
=========

Widgets for association rules.

"""

# Category description for the widget registry

NAME = "Basic Loops"

DESCRIPTION = "Widgets for Shadow - Basic Loops"

#BACKGROUND = "#f0d3f3"
BACKGROUND = "#A9D0F5"

ICON = "icons/loop_management.png"

PRIORITY = 107

